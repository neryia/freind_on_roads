﻿namespace WindowsFormsApp10
{
    partial class menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.drags = new System.Windows.Forms.Button();
            this.smart_al = new System.Windows.Forms.Button();
            this.Query = new System.Windows.Forms.Button();
            this.costumer = new System.Windows.Forms.Button();
            this.events = new System.Windows.Forms.Button();
            this.valunteers = new System.Windows.Forms.Button();
            this.costumer_form = new System.Windows.Forms.Button();
            this.val_form = new System.Windows.Forms.Button();
            this.errors = new System.Windows.Forms.Button();
            this.hamal = new System.Windows.Forms.Button();
            this.menu_labal = new System.Windows.Forms.Label();
            this.user_add = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // drags
            // 
            this.drags.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.drags.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.drags.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.drags.ForeColor = System.Drawing.Color.White;
            this.drags.Location = new System.Drawing.Point(29, 85);
            this.drags.Name = "drags";
            this.drags.Size = new System.Drawing.Size(214, 55);
            this.drags.TabIndex = 1;
            this.drags.Text = "גרירות";
            this.drags.UseVisualStyleBackColor = false;
            this.drags.Click += new System.EventHandler(this.drags_Click);
            // 
            // smart_al
            // 
            this.smart_al.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.smart_al.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.smart_al.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.smart_al.ForeColor = System.Drawing.Color.White;
            this.smart_al.Location = new System.Drawing.Point(282, 247);
            this.smart_al.Name = "smart_al";
            this.smart_al.Size = new System.Drawing.Size(215, 55);
            this.smart_al.TabIndex = 2;
            this.smart_al.Text = "אלגוריתם חכם";
            this.smart_al.UseVisualStyleBackColor = false;
            this.smart_al.Click += new System.EventHandler(this.smart_al_Click);
            // 
            // Query
            // 
            this.Query.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.Query.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Query.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Query.ForeColor = System.Drawing.Color.White;
            this.Query.Location = new System.Drawing.Point(560, 247);
            this.Query.Name = "Query";
            this.Query.Size = new System.Drawing.Size(198, 55);
            this.Query.TabIndex = 3;
            this.Query.Text = "שאילתות";
            this.Query.UseVisualStyleBackColor = false;
            this.Query.Click += new System.EventHandler(this.Query_Click);
            // 
            // costumer
            // 
            this.costumer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.costumer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.costumer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.costumer.ForeColor = System.Drawing.Color.White;
            this.costumer.Location = new System.Drawing.Point(560, 169);
            this.costumer.Name = "costumer";
            this.costumer.Size = new System.Drawing.Size(198, 55);
            this.costumer.TabIndex = 4;
            this.costumer.Text = "לקוחות";
            this.costumer.UseVisualStyleBackColor = false;
            this.costumer.Click += new System.EventHandler(this.costumer_Click);
            // 
            // events
            // 
            this.events.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.events.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.events.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.events.ForeColor = System.Drawing.Color.White;
            this.events.Location = new System.Drawing.Point(282, 169);
            this.events.Name = "events";
            this.events.Size = new System.Drawing.Size(215, 55);
            this.events.TabIndex = 5;
            this.events.Text = "אירועים";
            this.events.UseVisualStyleBackColor = false;
            this.events.Click += new System.EventHandler(this.events_Click);
            // 
            // valunteers
            // 
            this.valunteers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.valunteers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.valunteers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.valunteers.ForeColor = System.Drawing.Color.White;
            this.valunteers.Location = new System.Drawing.Point(29, 169);
            this.valunteers.Name = "valunteers";
            this.valunteers.Size = new System.Drawing.Size(214, 55);
            this.valunteers.TabIndex = 6;
            this.valunteers.Text = "כוננים";
            this.valunteers.UseVisualStyleBackColor = false;
            this.valunteers.Click += new System.EventHandler(this.valunteers_click);
            // 
            // costumer_form
            // 
            this.costumer_form.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.costumer_form.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.costumer_form.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.costumer_form.ForeColor = System.Drawing.Color.White;
            this.costumer_form.Location = new System.Drawing.Point(560, 85);
            this.costumer_form.Name = "costumer_form";
            this.costumer_form.Size = new System.Drawing.Size(198, 55);
            this.costumer_form.TabIndex = 7;
            this.costumer_form.Text = "טופס לקוח";
            this.costumer_form.UseVisualStyleBackColor = false;
            this.costumer_form.Click += new System.EventHandler(this.costumer_form_Click);
            // 
            // val_form
            // 
            this.val_form.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.val_form.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.val_form.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.val_form.ForeColor = System.Drawing.Color.White;
            this.val_form.Location = new System.Drawing.Point(282, 85);
            this.val_form.Name = "val_form";
            this.val_form.Size = new System.Drawing.Size(215, 55);
            this.val_form.TabIndex = 8;
            this.val_form.Text = "טופס כונן";
            this.val_form.UseVisualStyleBackColor = false;
            this.val_form.Click += new System.EventHandler(this.val_form_Click);
            // 
            // errors
            // 
            this.errors.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.errors.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.errors.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.errors.ForeColor = System.Drawing.Color.White;
            this.errors.Location = new System.Drawing.Point(29, 247);
            this.errors.Name = "errors";
            this.errors.Size = new System.Drawing.Size(214, 55);
            this.errors.TabIndex = 9;
            this.errors.Text = "תקלות";
            this.errors.UseVisualStyleBackColor = false;
            this.errors.Click += new System.EventHandler(this.errors_Click);
            // 
            // hamal
            // 
            this.hamal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.hamal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.hamal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.hamal.ForeColor = System.Drawing.Color.White;
            this.hamal.Location = new System.Drawing.Point(29, 343);
            this.hamal.Name = "hamal";
            this.hamal.Size = new System.Drawing.Size(468, 55);
            this.hamal.TabIndex = 10;
            this.hamal.Text = "חמ\"ל";
            this.hamal.UseVisualStyleBackColor = false;
            this.hamal.Click += new System.EventHandler(this.hamal_Click);
            // 
            // menu_labal
            // 
            this.menu_labal.BackColor = System.Drawing.Color.Transparent;
            this.menu_labal.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.menu_labal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.menu_labal.Location = new System.Drawing.Point(309, 9);
            this.menu_labal.Name = "menu_labal";
            this.menu_labal.Size = new System.Drawing.Size(155, 55);
            this.menu_labal.TabIndex = 0;
            this.menu_labal.Text = "תפריט";
            this.menu_labal.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // user_add
            // 
            this.user_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.user_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.user_add.ForeColor = System.Drawing.Color.White;
            this.user_add.Location = new System.Drawing.Point(560, 343);
            this.user_add.Name = "user_add";
            this.user_add.Size = new System.Drawing.Size(198, 55);
            this.user_add.TabIndex = 11;
            this.user_add.Text = "הוספת משתמש";
            this.user_add.UseVisualStyleBackColor = false;
            this.user_add.Click += new System.EventHandler(this.button1_Click);
            // 
            // menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApp10.Properties.Resources.backgruond1;
            this.ClientSize = new System.Drawing.Size(792, 450);
            this.Controls.Add(this.user_add);
            this.Controls.Add(this.menu_labal);
            this.Controls.Add(this.hamal);
            this.Controls.Add(this.errors);
            this.Controls.Add(this.val_form);
            this.Controls.Add(this.costumer_form);
            this.Controls.Add(this.valunteers);
            this.Controls.Add(this.events);
            this.Controls.Add(this.costumer);
            this.Controls.Add(this.Query);
            this.Controls.Add(this.smart_al);
            this.Controls.Add(this.drags);
            this.Name = "menu";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button drags;
        private System.Windows.Forms.Button smart_al;
        private System.Windows.Forms.Button Query;
        private System.Windows.Forms.Button costumer;
        private System.Windows.Forms.Button events;
        private System.Windows.Forms.Button valunteers;
        private System.Windows.Forms.Button costumer_form;
        private System.Windows.Forms.Button val_form;
        private System.Windows.Forms.Button errors;
        private System.Windows.Forms.Button hamal;
        private System.Windows.Forms.Label menu_labal;
        private System.Windows.Forms.Button user_add;
    }
}

