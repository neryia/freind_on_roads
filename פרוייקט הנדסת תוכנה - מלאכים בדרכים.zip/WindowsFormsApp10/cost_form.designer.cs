﻿namespace WindowsFormsApp10
{
    partial class cost_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.הוספתמשתמש = new System.Windows.Forms.ToolStripMenuItem();
            this.לקוחות = new System.Windows.Forms.ToolStripMenuItem();
            this.שאילתות = new System.Windows.Forms.ToolStripMenuItem();
            this.טופסכונן = new System.Windows.Forms.ToolStripMenuItem();
            this.אירועים = new System.Windows.Forms.ToolStripMenuItem();
            this.אלגוריתםחכם = new System.Windows.Forms.ToolStripMenuItem();
            this.גרירות = new System.Windows.Forms.ToolStripMenuItem();
            this.כוננים = new System.Windows.Forms.ToolStripMenuItem();
            this.תקלות = new System.Windows.Forms.ToolStripMenuItem();
            this.חמל = new System.Windows.Forms.ToolStripMenuItem();
            this.התנתקותToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_form_code = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_sound = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_cost_code = new System.Windows.Forms.ComboBox();
            this.txt_dengerous = new System.Windows.Forms.CheckBox();
            this.txt_starter = new System.Windows.Forms.CheckBox();
            this.btnshowall = new System.Windows.Forms.Button();
            this.txt_damage_visible = new System.Windows.Forms.CheckedListBox();
            this.btnsave = new System.Windows.Forms.Button();
            this.txt_knowledge = new System.Windows.Forms.ComboBox();
            this.update = new System.Windows.Forms.Button();
            this.light_show = new System.Windows.Forms.PictureBox();
            this.delete = new System.Windows.Forms.Button();
            this.clean = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.log = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txt_light = new System.Windows.Forms.CheckedListBox();
            this.txt_find_how = new System.Windows.Forms.ComboBox();
            this.btn_find = new System.Windows.Forms.Button();
            this.txt_find = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.light_show)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.הוספתמשתמש,
            this.לקוחות,
            this.שאילתות,
            this.טופסכונן,
            this.אירועים,
            this.אלגוריתםחכם,
            this.גרירות,
            this.כוננים,
            this.תקלות,
            this.חמל});
            this.toolStripMenuItem1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(63, 28);
            this.toolStripMenuItem1.Text = "ניווט";
            // 
            // הוספתמשתמש
            // 
            this.הוספתמשתמש.Name = "הוספתמשתמש";
            this.הוספתמשתמש.Size = new System.Drawing.Size(204, 28);
            this.הוספתמשתמש.Text = "הוספת משתמש";
            this.הוספתמשתמש.Click += new System.EventHandler(this.הוספתמשתמש_Click);
            // 
            // לקוחות
            // 
            this.לקוחות.Name = "לקוחות";
            this.לקוחות.Size = new System.Drawing.Size(204, 28);
            this.לקוחות.Text = "לקוחות";
            this.לקוחות.Click += new System.EventHandler(this.לקוחות_Click);
            // 
            // שאילתות
            // 
            this.שאילתות.Name = "שאילתות";
            this.שאילתות.Size = new System.Drawing.Size(204, 28);
            this.שאילתות.Text = "שאילתות";
            this.שאילתות.Click += new System.EventHandler(this.שאילתות_Click);
            // 
            // טופסכונן
            // 
            this.טופסכונן.Name = "טופסכונן";
            this.טופסכונן.Size = new System.Drawing.Size(204, 28);
            this.טופסכונן.Text = "טופס כונן";
            this.טופסכונן.Click += new System.EventHandler(this.טופסכונן_Click);
            // 
            // אירועים
            // 
            this.אירועים.Name = "אירועים";
            this.אירועים.Size = new System.Drawing.Size(204, 28);
            this.אירועים.Text = "אירועים";
            this.אירועים.Click += new System.EventHandler(this.אירועים_Click);
            // 
            // אלגוריתםחכם
            // 
            this.אלגוריתםחכם.Name = "אלגוריתםחכם";
            this.אלגוריתםחכם.Size = new System.Drawing.Size(204, 28);
            this.אלגוריתםחכם.Text = "אלגוריתם חכם";
            this.אלגוריתםחכם.Click += new System.EventHandler(this.אלגוריתםחכם_Click);
            // 
            // גרירות
            // 
            this.גרירות.Name = "גרירות";
            this.גרירות.Size = new System.Drawing.Size(204, 28);
            this.גרירות.Text = "גרירות";
            this.גרירות.Click += new System.EventHandler(this.גרירות_Click);
            // 
            // כוננים
            // 
            this.כוננים.Name = "כוננים";
            this.כוננים.Size = new System.Drawing.Size(204, 28);
            this.כוננים.Text = "כוננים";
            this.כוננים.Click += new System.EventHandler(this.כוננים_Click);
            // 
            // תקלות
            // 
            this.תקלות.Name = "תקלות";
            this.תקלות.Size = new System.Drawing.Size(204, 28);
            this.תקלות.Text = "תקלות";
            this.תקלות.Click += new System.EventHandler(this.תקלות_Click);
            // 
            // חמל
            // 
            this.חמל.Name = "חמל";
            this.חמל.Size = new System.Drawing.Size(204, 28);
            this.חמל.Text = "חמ\"ל";
            this.חמל.Click += new System.EventHandler(this.חמל_Click);
            // 
            // התנתקותToolStripMenuItem
            // 
            this.התנתקותToolStripMenuItem.Name = "התנתקותToolStripMenuItem";
            this.התנתקותToolStripMenuItem.Size = new System.Drawing.Size(98, 28);
            this.התנתקותToolStripMenuItem.Text = "התנתקות";
            this.התנתקותToolStripMenuItem.Click += new System.EventHandler(this.התנתקותToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.White;
            this.menuStrip1.Font = new System.Drawing.Font("Aharoni", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.התנתקותToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1024, 32);
            this.menuStrip1.TabIndex = 169;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.label1.Location = new System.Drawing.Point(870, 55);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(148, 33);
            this.label1.TabIndex = 119;
            this.label1.Text = "טפסי לקוחות";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(961, 97);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(40, 14);
            this.label2.TabIndex = 120;
            this.label2.Text = "מתניע?";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(897, 363);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(101, 14);
            this.label3.TabIndex = 121;
            this.label3.Text = "נורות אזהרה דולקות?";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(954, 149);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label4.Size = new System.Drawing.Size(47, 14);
            this.label4.TabIndex = 122;
            this.label4.Text = "נזק גלוי?";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(963, 118);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label5.Size = new System.Drawing.Size(38, 14);
            this.label5.TabIndex = 123;
            this.label5.Text = "קולות?";
            // 
            // txt_form_code
            // 
            this.txt_form_code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(92)))), ((int)(((byte)(136)))));
            this.txt_form_code.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.txt_form_code.ForeColor = System.Drawing.Color.White;
            this.txt_form_code.Location = new System.Drawing.Point(727, 203);
            this.txt_form_code.Name = "txt_form_code";
            this.txt_form_code.ReadOnly = true;
            this.txt_form_code.Size = new System.Drawing.Size(162, 20);
            this.txt_form_code.TabIndex = 124;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(952, 206);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label6.Size = new System.Drawing.Size(49, 14);
            this.label6.TabIndex = 125;
            this.label6.Text = "קוד טופס";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(918, 243);
            this.label7.Name = "label7";
            this.label7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label7.Size = new System.Drawing.Size(83, 14);
            this.label7.TabIndex = 126;
            this.label7.Text = "יודע מה התקלה?";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(951, 287);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 14);
            this.label8.TabIndex = 127;
            this.label8.Text = "קוד לקוח";
            // 
            // txt_sound
            // 
            this.txt_sound.AutoSize = true;
            this.txt_sound.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(92)))), ((int)(((byte)(136)))));
            this.txt_sound.Location = new System.Drawing.Point(798, 119);
            this.txt_sound.Name = "txt_sound";
            this.txt_sound.Size = new System.Drawing.Size(15, 14);
            this.txt_sound.TabIndex = 137;
            this.txt_sound.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(905, 323);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 14);
            this.label9.TabIndex = 141;
            this.label9.Text = "נמצא במקום מסוכן";
            // 
            // txt_cost_code
            // 
            this.txt_cost_code.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(92)))), ((int)(((byte)(136)))));
            this.txt_cost_code.ForeColor = System.Drawing.Color.White;
            this.txt_cost_code.FormattingEnabled = true;
            this.txt_cost_code.Location = new System.Drawing.Point(727, 284);
            this.txt_cost_code.Name = "txt_cost_code";
            this.txt_cost_code.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_cost_code.Size = new System.Drawing.Size(162, 22);
            this.txt_cost_code.TabIndex = 142;
            // 
            // txt_dengerous
            // 
            this.txt_dengerous.AutoSize = true;
            this.txt_dengerous.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(15)))), ((int)(((byte)(84)))));
            this.txt_dengerous.Location = new System.Drawing.Point(798, 323);
            this.txt_dengerous.Name = "txt_dengerous";
            this.txt_dengerous.Size = new System.Drawing.Size(15, 14);
            this.txt_dengerous.TabIndex = 143;
            this.txt_dengerous.UseVisualStyleBackColor = false;
            // 
            // txt_starter
            // 
            this.txt_starter.AutoSize = true;
            this.txt_starter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(92)))), ((int)(((byte)(136)))));
            this.txt_starter.Location = new System.Drawing.Point(798, 98);
            this.txt_starter.Name = "txt_starter";
            this.txt_starter.Size = new System.Drawing.Size(15, 14);
            this.txt_starter.TabIndex = 144;
            this.txt_starter.UseVisualStyleBackColor = false;
            // 
            // btnshowall
            // 
            this.btnshowall.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.btnshowall.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnshowall.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btnshowall.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.btnshowall.Location = new System.Drawing.Point(686, 554);
            this.btnshowall.Name = "btnshowall";
            this.btnshowall.Size = new System.Drawing.Size(110, 52);
            this.btnshowall.TabIndex = 129;
            this.btnshowall.Text = "הצג הכל";
            this.btnshowall.UseVisualStyleBackColor = false;
            this.btnshowall.Click += new System.EventHandler(this.btnshowall_Click);
            // 
            // txt_damage_visible
            // 
            this.txt_damage_visible.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(92)))), ((int)(((byte)(136)))));
            this.txt_damage_visible.ForeColor = System.Drawing.Color.White;
            this.txt_damage_visible.FormattingEnabled = true;
            this.txt_damage_visible.Items.AddRange(new object[] {
            "עשן",
            "עף גלגל",
            "פנצ\'ר"});
            this.txt_damage_visible.Location = new System.Drawing.Point(730, 139);
            this.txt_damage_visible.Name = "txt_damage_visible";
            this.txt_damage_visible.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_damage_visible.Size = new System.Drawing.Size(159, 38);
            this.txt_damage_visible.TabIndex = 146;
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.btnsave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btnsave.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.btnsave.Location = new System.Drawing.Point(937, 489);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 51);
            this.btnsave.TabIndex = 128;
            this.btnsave.Text = "שמור";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // txt_knowledge
            // 
            this.txt_knowledge.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(92)))), ((int)(((byte)(136)))));
            this.txt_knowledge.ForeColor = System.Drawing.Color.White;
            this.txt_knowledge.FormattingEnabled = true;
            this.txt_knowledge.Location = new System.Drawing.Point(727, 243);
            this.txt_knowledge.Name = "txt_knowledge";
            this.txt_knowledge.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_knowledge.Size = new System.Drawing.Size(162, 22);
            this.txt_knowledge.TabIndex = 147;
            // 
            // update
            // 
            this.update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.update.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.update.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.update.Location = new System.Drawing.Point(686, 490);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(110, 51);
            this.update.TabIndex = 132;
            this.update.Text = "עדכון";
            this.update.UseVisualStyleBackColor = false;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // light_show
            // 
            this.light_show.BackColor = System.Drawing.Color.Transparent;
            this.light_show.Location = new System.Drawing.Point(766, 404);
            this.light_show.Name = "light_show";
            this.light_show.Size = new System.Drawing.Size(100, 54);
            this.light_show.TabIndex = 148;
            this.light_show.TabStop = false;
            // 
            // delete
            // 
            this.delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.delete.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.delete.Location = new System.Drawing.Point(812, 489);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(110, 52);
            this.delete.TabIndex = 134;
            this.delete.Text = "מחק";
            this.delete.UseVisualStyleBackColor = false;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // clean
            // 
            this.clean.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.clean.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.clean.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.clean.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.clean.Location = new System.Drawing.Point(812, 555);
            this.clean.Name = "clean";
            this.clean.Size = new System.Drawing.Size(110, 51);
            this.clean.TabIndex = 133;
            this.clean.Text = "ניקוי";
            this.clean.UseVisualStyleBackColor = false;
            this.clean.Click += new System.EventHandler(this.clean_Click);
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.back.ForeColor = System.Drawing.Color.White;
            this.back.Location = new System.Drawing.Point(937, 555);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 52);
            this.back.TabIndex = 130;
            this.back.Text = "חזור";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // log
            // 
            this.log.AutoSize = true;
            this.log.BackColor = System.Drawing.Color.Transparent;
            this.log.Font = new System.Drawing.Font("Calibri", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.log.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.log.Location = new System.Drawing.Point(7, 581);
            this.log.Name = "log";
            this.log.Size = new System.Drawing.Size(60, 29);
            this.log.TabIndex = 131;
            this.log.Text = "LOG:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(92)))), ((int)(((byte)(136)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 58);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(674, 421);
            this.dataGridView1.TabIndex = 149;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.click_event);
            // 
            // txt_light
            // 
            this.txt_light.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(92)))), ((int)(((byte)(136)))));
            this.txt_light.ForeColor = System.Drawing.Color.White;
            this.txt_light.FormattingEnabled = true;
            this.txt_light.Location = new System.Drawing.Point(727, 343);
            this.txt_light.Name = "txt_light";
            this.txt_light.Size = new System.Drawing.Size(162, 55);
            this.txt_light.TabIndex = 165;
            this.txt_light.SelectedIndexChanged += new System.EventHandler(this.txt_light_SelectedIndexChanged_1);
            // 
            // txt_find_how
            // 
            this.txt_find_how.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(92)))), ((int)(((byte)(136)))));
            this.txt_find_how.Enabled = false;
            this.txt_find_how.ForeColor = System.Drawing.Color.White;
            this.txt_find_how.FormattingEnabled = true;
            this.txt_find_how.Location = new System.Drawing.Point(434, 542);
            this.txt_find_how.Name = "txt_find_how";
            this.txt_find_how.Size = new System.Drawing.Size(94, 22);
            this.txt_find_how.TabIndex = 166;
            this.txt_find_how.Visible = false;
            // 
            // btn_find
            // 
            this.btn_find.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(107)))), ((int)(((byte)(173)))));
            this.btn_find.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.btn_find.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.btn_find.Location = new System.Drawing.Point(554, 525);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(110, 51);
            this.btn_find.TabIndex = 167;
            this.btn_find.Text = "חפש לפי";
            this.btn_find.UseVisualStyleBackColor = false;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // txt_find
            // 
            this.txt_find.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(92)))), ((int)(((byte)(136)))));
            this.txt_find.Enabled = false;
            this.txt_find.ForeColor = System.Drawing.Color.White;
            this.txt_find.Location = new System.Drawing.Point(292, 542);
            this.txt_find.Name = "txt_find";
            this.txt_find.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_find.Size = new System.Drawing.Size(136, 22);
            this.txt_find.TabIndex = 168;
            this.txt_find.Visible = false;
            this.txt_find.TextChanged += new System.EventHandler(this.txt_find_text_changed);
            // 
            // cost_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.BackgroundImage = global::WindowsFormsApp10.Properties.Resources.backgruond1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1024, 622);
            this.Controls.Add(this.txt_find);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_find_how);
            this.Controls.Add(this.txt_light);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.log);
            this.Controls.Add(this.back);
            this.Controls.Add(this.clean);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.light_show);
            this.Controls.Add(this.update);
            this.Controls.Add(this.txt_knowledge);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.txt_damage_visible);
            this.Controls.Add(this.btnshowall);
            this.Controls.Add(this.txt_starter);
            this.Controls.Add(this.txt_dengerous);
            this.Controls.Add(this.txt_cost_code);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_sound);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_form_code);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Calibri", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "cost_form";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.updatefields);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.light_show)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem הוספתמשתמש;
        private System.Windows.Forms.ToolStripMenuItem לקוחות;
        private System.Windows.Forms.ToolStripMenuItem שאילתות;
        private System.Windows.Forms.ToolStripMenuItem טופסכונן;
        private System.Windows.Forms.ToolStripMenuItem אירועים;
        private System.Windows.Forms.ToolStripMenuItem אלגוריתםחכם;
        private System.Windows.Forms.ToolStripMenuItem גרירות;
        private System.Windows.Forms.ToolStripMenuItem כוננים;
        private System.Windows.Forms.ToolStripMenuItem תקלות;
        private System.Windows.Forms.ToolStripMenuItem חמל;
        private System.Windows.Forms.ToolStripMenuItem התנתקותToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_form_code;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox txt_sound;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox txt_cost_code;
        private System.Windows.Forms.CheckBox txt_dengerous;
        private System.Windows.Forms.CheckBox txt_starter;
        private System.Windows.Forms.Button btnshowall;
        private System.Windows.Forms.CheckedListBox txt_damage_visible;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.ComboBox txt_knowledge;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.PictureBox light_show;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button clean;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Label log;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.CheckedListBox txt_light;
        private System.Windows.Forms.ComboBox txt_find_how;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.TextBox txt_find;
    }
}